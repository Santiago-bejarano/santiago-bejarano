<ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2 active" aria-current="page" href="#">
                <svg class="bi"><use xlink:href="#house-fill"/></svg>
                Itfip
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Matricula.php">
                <svg class="bi"><use xlink:href="Matricula.php"/></svg>
                Matricula
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Contenido.php">
                <svg class="bi"><use xlink:href="Contenido.php"/></svg>
                contenido
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Historia.php">
                <svg class="bi"><use xlink:href="Historia.php"/></svg>
                Historia
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Pagos.php">
                <svg class="bi"><use xlink:href="Pagos.php"/></svg>
                Pagos
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Clases.php">
                <svg class="bi"><use xlink:href="Clases.php"/></svg>
                Clases
              </a>
            </li>
          </ul>
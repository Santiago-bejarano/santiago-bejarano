<?php
$cosas=$_POST["compras"];
$gasto =$_POST["gasto"] ;
if($gasto<100000 and $gasto>0 )
{
    echo $cosas." compras";
    echo "<br>";
    echo "".$gasto." gasto";
}else
{
    echo "hacker lo siento";
}

?>
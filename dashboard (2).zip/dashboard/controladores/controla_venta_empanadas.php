<?php
$cantidad_empanadas=$_POST["cantidad"];
$empanadas = 2500;

if($cantidad_empanadas>0)
{
    $total=$cantidad_empanadas*$empanadas;
    echo $total."valor";
}else
{
    echo "hacker lo siento";
}

?>
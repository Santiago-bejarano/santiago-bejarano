<?php
$nombre = $_POST["nom"];
$documento = $_POST["docu"];
$edad = $_POST["edad"];
if($edad >= 18) 
{
//aca es cuando si
echo "nombre:".$nombre;
echo "<br> documento:".$documento;
echo "<br> edad:".$edad;
}else
{
//aca cuando no
echo "eche pa la casa";
}
?>